const product = [
    {
        id: 0,
        image: '3.jpg',
        title: 'AUSTRALIS',
        price: 40,
       
        
        
        
    },
    {
        id: 1,
        image: '4.jpg',
        title: 'FLORENCE',
        price: 60,
        
    },
    {
        id: 2,
        image: '2.jpg',
        title: 'CALM',
        price: 40,
        
    },
    {
        id: 3,
        image: '1.jpg',
        title: 'ACAPULCO',
        price: 40,
        
    },
   
];

  
const categories = [...new Set(product.map((item)=>
    {return item}))]
    let i=0;
document.getElementById('root').innerHTML = categories.map((item)=>
{
    var {image, title, price} = item;
    return(
        `<div class='box'>
            <div class='img-box'>
                <img class='images' src=${image}></img>
            </div>
        <div class='bottom'>
        <p>${title}</p>
        <h2>$ ${price}.00</h2>`+
        "<button onclick='addtocart("+(i++)+")'>Add to cart</button>"+
        `</div>
        </div>`
    )
    

}).join('')

// ... your existing code


const images = document.querySelectorAll('.images');

images.forEach((image, index) => {
    // Add event listener for image click
    image.addEventListener('click', () => {
        switch (index) {
            case 0:
                window.location.href = 'AUSTRALIS.html';
                break;
            case 1:
                window.location.href = 'FLORENCE.html';
                break;
            case 2:
                window.location.href = 'CALM.html';
                break;
            case 3:
                window.location.href = 'ACAPULCO.html';
                break;
            
        }
    });
});




// ... further code



var cart =[];



function addtocart(a){
    cart.push({...categories[a]});
    displaycart();
}
function delElement(a){
    cart.splice(a, 1);
    displaycart();
}

function displaycart(){
    let j = 0, total=0; discount=0;
    document.getElementById("count").innerHTML=cart.length;
    if(cart.length==0){
        document.getElementById('cartItem').innerHTML = "Your cart is empty";
        document.getElementById("total").innerHTML = "$ "+0+".00";
        document.getElementById("dis").innerHTML = "$ "+0+".00";
    }
    else{
        document.getElementById("cartItem").innerHTML = cart.map((items)=>
        {
            var {image, title, price} = items;
            total=total+price;

            if (total > 500) {
                discount = 0.50;
            } else if (total >= 200 && total <= 499) {
                discount = 0.30;
            }else {
                discount = 0;
            }


            // Calculate total cost after applying discount
            var totalCost = total - (total * discount);


            document.getElementById("total").innerHTML = "$ "+total+".00";
            document.getElementById("dis").innerHTML = "$ "+totalCost+".00";

            return(
                `<div class='cart-item'>
                <div class='row-img'>
                    <img class='rowimg' src=${image}>
                </div>
                <p style='font-size:12px;'>${title}</p>
                <h2 style='font-size: 15px;'>$ ${price}.00</h2>`+
                "<i class='fa-solid fa-trash' onclick='delElement("+ (j++) +")'></i></div>"
            );
        }).join('');
    }

    

    
}